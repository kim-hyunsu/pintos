#include <stdio.h>

int hello(void) {
  printf("hello, world!\n");
  return 0;
}
